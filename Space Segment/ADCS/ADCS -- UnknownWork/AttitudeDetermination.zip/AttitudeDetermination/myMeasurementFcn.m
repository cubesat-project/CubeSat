function [y] = myMeasurementFcn (x)
%y=x(1);
y=x;
end