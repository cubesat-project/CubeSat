%Atttitude Propagator Function
%r defines the x y plane of the current attitude
%r=[x;y]
%function rhat=Attitude_Propagator(roll,pitch,yaw,r)
r=[1,0,0;0,1,0;0,0,1]

p1=[r(1,:)];
p2=[r(2,:)];
p3=cross(p1,p2);

for(i=1:62501)
    delta=0.32;    %time step
    w_roll=ang_vel(i,1);   %roll angluar rate
    w_pitch=ang_vel(i,2);  %pitch angular rate
    w_yaw=ang_vel(i,3);    %yaw angular rate

    % %obtaining the quaternion corresponding the rotation of the satellite

    %get the quaternion that will produce the rotation dictated by the
    %gyroscope measured rates ,w.
    plot3(p1(1),p1(2),p1(3),'bo')
    hold on
    grid on
    axis([-1 1 -1 1 -1 1])
    xlabel('x')
    ylabel('y')
    zlabel('z')

    plot3(p2(1),p2(2),p2(3),'ro');
    plot3(p3(1),p3(2),p3(3),'mo');

    a=w_roll*delta;     %change about x-axis
    b=w_pitch*delta;    %change about y-axis
    c=w_yaw*delta;      %change about z-axis

    a=deg2rad(a);
    b=deg2rad(b);
    c=deg2rad(c);

    curquat=quaternion([c,b,a],'euler','ZYX','point');


    %how rotation effects the reference point previously plotted.

    rotatedframe=rotateframe(curquat,[p1;p2;p3]);


    plot3(rotatedframe(1,1),rotatedframe(1,2),rotatedframe(1,3),'bd')
    plot3(rotatedframe(2,1),rotatedframe(2,2),rotatedframe(2,3),'rd')
    plot3(rotatedframe(3,1),rotatedframe(3,2),rotatedframe(3,3),'md')

    plot3([0;rotatedframe(1,1)],[0;rotatedframe(1,2)],[0;rotatedframe(1,3)],'k')
    plot3([0;rotatedframe(2,1)],[0;rotatedframe(2,2)],[0;rotatedframe(2,3)],'k')
    plot3([0;rotatedframe(3,1)],[0;rotatedframe(3,2)],[0;rotatedframe(3,3)],'k')
    plot3([0;p1(1)],[0;p1(2)],[0;p1(3)],'k')
    plot3([0;p2(1)],[0;p2(2)],[0;p2(3)],'k')
    plot3([0;p3(1)],[0;p3(2)],[0;p3(3)],'k')
    
    drawnow
    hold off

    p1=[rotatedframe(1,1),rotatedframe(1,2),rotatedframe(1,3)];

    p2=[rotatedframe(2,1),rotatedframe(2,2),rotatedframe(2,3)];

    p3=[rotatedframe(3,1),rotatedframe(3,2),rotatedframe(3,3)];

    rhat=[p1;p2;p3];
end

%end
     
     
 






